
import java.util.*;


/**
 * Class Jugador
 */
public class Jugador {

  //
  // Fields
  //

  private int altura;
  private int PosicioX;
  private int PosicioY;
  private Flor Romper_Bloques;
  
  //
  // Constructors
  //
  public Jugador () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  /**
   * Set the value of altura
   * @param newVar the new value of altura
   */
  public void setAltura (int newVar) {
    altura = newVar;
  }

  /**
   * Get the value of altura
   * @return the value of altura
   */
  public int getAltura () {
    return altura;
  }

  /**
   * Set the value of PosicioX
   * @param newVar the new value of PosicioX
   */
  public void setPosicioX (int newVar) {
    PosicioX = newVar;
  }

  /**
   * Get the value of PosicioX
   * @return the value of PosicioX
   */
  public int getPosicioX () {
    return PosicioX;
  }

  /**
   * Set the value of PosicioY
   * @param newVar the new value of PosicioY
   */
  public void setPosicioY (int newVar) {
    PosicioY = newVar;
  }

  /**
   * Get the value of PosicioY
   * @return the value of PosicioY
   */
  public int getPosicioY () {
    return PosicioY;
  }

  /**
   * Set the value of Romper_Bloques
   * @param newVar the new value of Romper_Bloques
   */
  public void setRomper_Bloques (Flor newVar) {
    Romper_Bloques = newVar;
  }

  /**
   * Get the value of Romper_Bloques
   * @return the value of Romper_Bloques
   */
  public Flor getRomper_Bloques () {
    return Romper_Bloques;
  }

  //
  // Other methods
  //

  /**
   * @return       int
   */
  public int getPosiciónX()
  {
  }


  /**
   * @return       int
   */
  public int setPosiciónX()
  {
  }


  /**
   * @return       int
   */
  public int getPosiciónY()
  {
  }


  /**
   * @return       int
   */
  public int setPosiciónY()
  {
  }


  /**
   * @return       Flor
   */
  public Flor Disparar()
  {
  }


  /**
   */
  public void Saltar()
  {
  }


  /**
   */
  public void Mover()
  {
  }


  /**
   */
  public void RomperBloques()
  {
  }


  /**
   */
  public void Correr()
  {
  }


  /**
   */
  public void Aplastar()
  {
  }


  /**
   * @return       Enemigos
   */
  public Enemigos RecibirDaño()
  {
  }


  /**
   * @return       short int
   */
  public short int LímiteDeBolasDeFuego()
  {
  }


  /**
   */
  public void Pausar()
  {
  }


  /**
   */
  public void girar()
  {
  }


  /**
   */
  public void Agacharse()
  {
  }


  /**
   * @return       Flor
   */
  public Flor Crecer()
  {
  }


  /**
   */
  public void Dirección()
  {
  }


  /**
   */
  public void Total_de_puntos()
  {
  }


}
