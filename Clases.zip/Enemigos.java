
import java.util.*;


/**
 * Class Enemigos
 */
public class Enemigos {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public Enemigos () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   */
  public void Hacer_Daño()
  {
  }


  /**
   */
  public void Caminar()
  {
  }


  /**
   */
  public void Dirección()
  {
  }


  /**
   * @return       Jugador
   */
  public Jugador Puntos()
  {
  }


}
