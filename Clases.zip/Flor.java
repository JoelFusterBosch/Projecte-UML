

/**
 * Class Flor
 */
public class Flor {

  //
  // Fields
  //

  
  //
  // Constructors
  //
  public Flor () { };
  
  //
  // Methods
  //


  //
  // Accessor methods
  //

  //
  // Other methods
  //

  /**
   */
  public void Crecer()
  {
  }


  /**
   */
  public void Disparar()
  {
  }


}
